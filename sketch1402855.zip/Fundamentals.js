function preload() {
	vid = createVideo('159647-t7zUUS6UxMwebm.webm');
	vid.loop();
	//vid.hide();
}

var p1X;
var p1Y;
var p2X;
var p2Y;
var p1XVel = 0;
var p1YVel = 0;
var p2XVel = 0;
var p2YVel = 0;
var ballX = 0;
var ballY = 0;
var ballXVel = 0;
var ballYVel = 0;
var jumping1 = false;
var jumping2 = false;
var cool = 0;
var screen = 0;
var p1Score = 0;
var p2Score = 0;

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	p1X = windowWidth * (2 / 10);
	p1Y = windowHeight * (9 / 10);
	p2X = windowWidth * (8 / 10);
	p2Y = windowHeight * (9 / 10);
	ballX = windowWidth / 2;
	ballY = 0;

	textAlign(CENTER);
	background(200);
	sel = createSelect();
	sel.position(10, 10);
	sel.size(windowWidth / 1.05, windowHeight / 3);
	sel.selected('Classic');
	sel.option('Classic');
	sel.option('Powerup');
	sel.option('Solo');
	sel.hide();
	sel.style('text-align', 'CENTER');
	sel.style('background-color', '#000000');
	sel.style('color', '#ffffff');
	sel.style('font-size', windowWidth / 15 + 'px');
	acceptb = createButton('Accept');
	acceptb.mouseReleased(clickAccept);
	acceptb.position(windowWidth / 2.2, windowHeight * (5 / 6));
	acceptb.size(windowWidth / 10, windowHeight / 30);
	acceptb.hide();
}

function draw() {
	vid.size(windowWidth, windowHeight);
	resizeCanvas(windowWidth, windowHeight);
	if (screen == 0) {
		sel.hide();
		resizeCanvas(windowWidth, windowHeight);
		homeScreen();
		acceptb.hide();
	} else if (screen == 1) {
		selectScreen();
		sel.show();
		acceptb.show();
	} else if (screen == 2) {
		sel.hide();
		soccerScreen();
		acceptb.hide();
	}
}

function homeScreen() {
	//noCanvas();
	resizeCanvas(0, 0);
}

function soccerScreen() {
	textAlign(CENTER, CENTER);
	clear();
	noStroke();
	background(150, 150, 255);
	fill(0);
	textSize(windowWidth / 10);
	text(p1Score, windowWidth * (1 / 10), windowHeight * (1 / 5));
	text(p2Score, windowWidth * (9 / 10), windowHeight * (1 / 5));
	rectMode(CORNERS);
	fill(50, 200, 0);
	rect(0, windowHeight * (9 / 10), windowWidth, windowHeight);
	strokeWeight(windowHeight / 50);
	stroke(0);
	line(0, 0, windowWidth, 0);
	line(0, 0, 0, windowHeight * (9 / 10));
	line(windowWidth, 0, windowWidth, windowHeight * (9 / 10));
	stroke(255);
	line(0, windowHeight * (8 / 15), 0, windowHeight * (9 / 10));
	line(windowWidth * (1 / 25), windowHeight * (8 / 15), windowWidth * (1 / 25), windowHeight * (9 / 10));
	line(windowWidth, windowHeight * (8 / 15), windowWidth, windowHeight * (9 / 10));
	line(windowWidth * (24 / 25), windowHeight * (8 / 15), windowWidth * (24 / 25), windowHeight * (9 / 10));
	stroke(0);
	line(0, windowHeight * (8 / 15), windowWidth * (1 / 25), windowHeight * (8 / 15));
	line(windowWidth, windowHeight * (8 / 15), windowWidth * (24 / 25), windowHeight * (8 / 15));
	noFill();
	stroke(255, 0, 0);
	ellipseMode(CENTER);
	ellipse(p1X, p1Y - (windowHeight / 30), windowWidth / 40, windowHeight / 15);
	stroke(0, 0, 255);
	ellipse(p2X, p2Y - (windowHeight / 30), windowWidth / 40, windowHeight / 15);
	if (keyIsDown(65)) {
		p1XVel -= 0.5;
	}
	if (keyIsDown(68)) {
		p1XVel += 0.5;
	}
	if (sel.value() != 'Solo') {
		if (keyIsDown(LEFT_ARROW)) {
			p2XVel -= 0.5;
		}
		if (keyIsDown(RIGHT_ARROW)) {
			p2XVel += 0.5;
		}
	}
	if (keyIsDown(87)) {
		if (!jumping1) {
			p1YVel = -9;
			jumping1 = true;
		}
	}
	if (sel.value() != 'Solo') {
		if (keyIsDown(UP_ARROW)) {
			if (!jumping2) {
				p2YVel = -9;
				jumping2 = true;
			}
		}
	} else {
		if (ballX > p2X - (windowWidth / 45)) {
			if (p2X < windowWidth * (22 / 25)) {
				p2XVel += 0.5;
			}
			if (!jumping2) {
				jumping2 = true;
				p2YVel = -9;
			}
		}
		if (ballX < p2X + (windowWidth / 45)) {
			if (ballXVel > 0) {
				if (p2X < windowWidth * (22 / 25)) {
					p2XVel += 0.5;
				}
			} else {
				p2XVel -= 0.5;
			}
		}
	}
	if (p1Y > windowHeight * (9 / 10)) {
		jumping1 = false;
		p1YVel = 0;
		p1Y = windowHeight * (9 / 10);
	}
	if (p2Y > windowHeight * (9 / 10)) {
		jumping2 = false;
		p2YVel = 0;
		p2Y = windowHeight * (9 / 10);
	}
	if (jumping1 == true) {
		p1YVel += 0.25;
		p1Y += p1YVel;
	} else {
		p1yVel = 0;
	}
	if (jumping2 == true) {
		p2YVel += 0.25;
		p2Y += p2YVel;
	} else {
		p2YVel = 0;
	}
	p1X += p1XVel;
	p2X += p2XVel;
	p1XVel *= 0.9;
	p2XVel *= 0.9;
	if (ballY < windowHeight * (9 / 10)) {
		ballYVel += 0.1;
	} else {
		ballY = (windowHeight * (9 / 10)) + 1;
		ballYVel *= -(1 / 2);
	}
	ballY += ballYVel;
	stroke(255);
	if (ballY < 0) {
		bally = 0;
		ballYVel *= -1;
	}
	if (ballX < 0) {
		ballx = 0;
		ballXVel *= -1;
	}
	if (ballX > windowWidth) {
		ballx = windowWidth;
		ballXVel *= -1;
	}
	ellipse(ballX, ballY - (windowHeight / 25), windowWidth / 45, windowWidth / 45);
	if (((p1X - ballX) * (p1X - ballX)) + ((p1Y - ballY) * (p1Y - ballY)) < windowWidth * 1.5) {
		ballX += p1XVel * 1;
		ballY += p1YVel * 1;
		ballXVel += ((ballX - p1X) / 10) + p1XVel;
		//if (cool > 15) {
		cool = 0;
		ballYVel += ((ballY - p1Y) / 10) + (p1YVel);
		//}
	}
	if (((p2X - ballX) * (p2X - ballX)) + ((p2Y - ballY) * (p2Y - ballY)) < windowWidth * 1.5) {
		ballX += p2XVel * 1;
		ballY += p2YVel * 1;
		ballXVel += ((ballX - p2X) / 10) + p2XVel;
		//if (cool > 15) {
		cool = 0;
		ballYVel += ((ballY - p2Y) / 10) + (p2YVel);
		//}
	}
	if (ballYVel < -15) {
		ballYVel = -15;
	}
	if (ballXVel < -15) {
		ballXVel = -15;
	}
	if (ballXVel > 15) {
		ballXVel = 15;
	}
	ballXVel *= 0.995;
	ballX += ballXVel;
	cool++;
	if (ballX < windowWidth * (1 / 25) && ballY > windowHeight * (9 / 15)) {
		p2Score++;
		ballX = windowWidth / 2;
		ballY = 0;
		ballXVel = random(-2, 2) * 5;
		ballYVel = 0;
		p1X = windowWidth * (2 / 10);
		p1Y = windowHeight * (9 / 10);
		p2X = windowWidth * (8 / 10);
		p2Y = windowHeight * (9 / 10);
		p1XVel = 0;
		p2XVel = 0;
		p1YVel = 0;
		p2YVel = 0;
	}
	if (ballX > windowWidth * (24 / 25) && ballY > windowHeight * (9 / 15)) {
		p1Score++;
		ballX = windowWidth / 2;
		ballY = 0;
		ballXVel = random(-2, 2) * 5;
		ballYVel = 0;
		p1X = windowWidth * (2 / 10);
		p1Y = windowHeight * (9 / 10);
		p2X = windowWidth * (8 / 10);
		p2Y = windowHeight * (9 / 10);
		p1XVel = 0;
		p2XVel = 0;
		p1YVel = 0;
		p2YVel = 0;
	}
	if (ballX < windowWidth * (1 / 25) && ballY < windowHeight * (9 / 15) && ballY > windowHeight * (7.8 / 15)) {
		ballYVel *= -1;
		ballY += ballYVel * 1.5;
	}
	if (ballX > windowWidth * (24 / 25) && ballY < windowHeight * (9 / 15) && ballY > windowHeight * (7.8 / 15)) {
		ballYVel *= -1;
		ballY += ballYVel * 1.5;
	}
}

function selectScreen() {
	resizeCanvas(windowWidth, windowHeight);
}

function mousePressed() {
	if (screen == 0) {
		vid.hide();
		screen = 1;
	}
}

function clickAccept() {
	screen = 2;
}